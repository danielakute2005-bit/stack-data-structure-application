STACK DATA STRUCTURE PROJECT

Application: Undo / Stack Simulator

Files:
- stack_application.html: the complete web application.
- Stack_Data_Structure_Assignment.pdf: the written assignment.

Deployment:
Upload stack_application.html to a static hosting service such as GitHub Pages, Netlify, or Vercel. Because the application is contained in one HTML file, no build step is required.

To use:
Open stack_application.html in a browser. Enter an action and click Push. Use Pop (Undo) to remove the most recent action. Peek shows the top item.
